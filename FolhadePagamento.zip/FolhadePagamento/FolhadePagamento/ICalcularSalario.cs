﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace FolhadePagamento
{
    public interface ICalcularSalario
    {
        double Calcular(double SalarioHora); // assinattura        void imprimir(); // assinatura    }

        void imprimir();
    }
}